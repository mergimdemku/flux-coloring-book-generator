"""Models package for FLUX Coloring Book Generator"""

from .flux_loader import FluxModelLoader

__all__ = ['FluxModelLoader']